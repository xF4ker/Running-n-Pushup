package com.example.toosie.Data.Storage;

public class Position {

    public double longitude;
    public double latitude;

    public Position(final double longitude, final double latitude) {
        this.longitude = longitude;
        this.latitude = latitude;
    }
}
